﻿using System;

namespace spaccamiglio.luca._4H.poligono
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("programma poligono scritto da Luca Spaccamiglio 4H");
            Console.WriteLine("inserire numero lati poligono");
            string strnLati = Console.ReadLine();
            Console.WriteLine("inserire lunghezza del lato");
            string strnLunghezza = Console.ReadLine();
            Poligono figura = new Poligono (Convert.ToInt32(strnLati), Convert.ToDouble(strnLunghezza));
            figura.Perimetro(figura.n, figura.lato);
            figura.Apotema(figura.n, figura.lato);
            figura.Area (figura.n, figura.lato);
            Console.WriteLine($"perimetro poligono={figura.perimetro}");
            Console.WriteLine($"apotema poligono={figura.apotema}");
            Console.WriteLine($"area poligono={figura.area}");
        }

        class Poligono
        {
            public double lato;
            public int n;
            public double nF;
            public double apotema;
            public double area;
            public double perimetro;

            public Poligono(int nlati,double L_lato)
            {
                lato = L_lato;
                n = nlati;
            }

            public void Perimetro(int n, double lato)
            {
                perimetro = n * lato;
            }

            public void Apotema(int n, double lato)
            {
                nF = 1 / (2 * Math.Tan(Math.PI / n));
                apotema = nF * lato;
            }

            public void Area(double apotema, double perimetro)
            {
                area = (perimetro * apotema) / 2;
            }

        }
    }
}
